./objects/sha512.o: ..\Mbedtls\library\sha512.c \
  ..\Mbedtls\include\mbedtls\config.h \
  ..\Mbedtls\include\mbedtls\check_config.h \
  D:\ARM\ARMCLANG\Bin\..\include\limits.h \
  ..\Mbedtls\include\mbedtls\sha512.h \
  D:\ARM\ARMCLANG\Bin\..\include\stddef.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ..\Mbedtls\include\mbedtls\platform_util.h \
  ..\Mbedtls\include\mbedtls\error.h \
  D:\ARM\ARMCLANG\Bin\..\include\string.h
