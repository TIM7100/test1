./objects/oid.o: ..\Mbedtls\library\oid.c \
  ..\Mbedtls\include\mbedtls\config.h \
  ..\Mbedtls\include\mbedtls\check_config.h \
  D:\ARM\ARMCLANG\Bin\..\include\limits.h \
  ..\Mbedtls\include\mbedtls\oid.h ..\Mbedtls\include\mbedtls\asn1.h \
  D:\ARM\ARMCLANG\Bin\..\include\stddef.h \
  ..\Mbedtls\include\mbedtls\bignum.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ..\Mbedtls\include\mbedtls\pk.h ..\Mbedtls\include\mbedtls\md.h \
  ..\Mbedtls\include\mbedtls\rsa.h ..\Mbedtls\include\mbedtls\cipher.h \
  ..\Mbedtls\include\mbedtls\platform_util.h \
  ..\Mbedtls\include\mbedtls\error.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\ARM\ARMCLANG\Bin\..\include\string.h \
  ..\Mbedtls\include\mbedtls\platform.h \
  ..\Mbedtls\include\mbedtls\platform_time.h \
  D:\ARM\ARMCLANG\Bin\..\include\time.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdlib.h
