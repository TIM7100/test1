./objects/utils_hmac.o: ..\HMAC\scr\utils_hmac.c ..\HMAC\inc\utils_hmac.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  D:\ARM\ARMCLANG\Bin\..\include\string.h ..\HMAC\inc\utils_md5.h \
  ..\HMAC\inc\utils_sha1.h
