./objects/dns.o: ..\Internet\Application\dns.c \
  D:\ARM\ARMCLANG\Bin\..\include\string.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdlib.h ..\Internet\W5500\socket.h \
  ..\Internet\W5500\wizchip_conf.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdint.h ..\Internet\W5500\w5500.h \
  ..\Internet\Application\dns.h
