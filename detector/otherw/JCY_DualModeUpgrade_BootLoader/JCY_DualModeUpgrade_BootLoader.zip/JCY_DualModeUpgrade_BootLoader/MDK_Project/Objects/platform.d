./objects/platform.o: ..\Mbedtls\library\platform.c \
  ..\Mbedtls\include\mbedtls\config.h \
  ..\Mbedtls\include\mbedtls\check_config.h \
  D:\ARM\ARMCLANG\Bin\..\include\limits.h \
  ..\Mbedtls\include\mbedtls\platform.h \
  ..\Mbedtls\include\mbedtls\platform_time.h \
  D:\ARM\ARMCLANG\Bin\..\include\time.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  ..\Mbedtls\include\mbedtls\platform_util.h \
  D:\ARM\ARMCLANG\Bin\..\include\stddef.h \
  ..\Mbedtls\include\mbedtls\error.h
