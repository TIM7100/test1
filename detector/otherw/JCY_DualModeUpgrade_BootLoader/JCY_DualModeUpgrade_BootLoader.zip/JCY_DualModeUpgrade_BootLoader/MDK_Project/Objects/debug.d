./objects/debug.o: ..\Mbedtls\library\debug.c \
  ..\Mbedtls\include\mbedtls\config.h \
  ..\Mbedtls\include\mbedtls\check_config.h \
  D:\ARM\ARMCLANG\Bin\..\include\limits.h
