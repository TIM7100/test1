./objects/utils_sha1.o: ..\HMAC\scr\utils_sha1.c ..\HMAC\inc\utils_sha1.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  D:\ARM\ARMCLANG\Bin\..\include\string.h
