./objects/wizchip_conf.o: ..\Internet\W5500\wizchip_conf.c \
  D:\ARM\ARMCLANG\Bin\..\include\stddef.h \
  ..\Internet\W5500\wizchip_conf.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdint.h ..\Internet\W5500\w5500.h
