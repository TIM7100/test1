./objects/utils_md5.o: ..\HMAC\scr\utils_md5.c ..\HMAC\inc\utils_md5.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdint.h \
  D:\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  D:\ARM\ARMCLANG\Bin\..\include\string.h
