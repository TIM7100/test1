./objects/mqttpacket.o: ..\Internet\MQTT\MQTTPacket.c \
  ..\Internet\MQTT\MQTTPacket.h ..\Internet\MQTT\MQTTConnect.h \
  ..\Internet\MQTT\MQTTPublish.h ..\Internet\MQTT\MQTTSubscribe.h \
  ..\Internet\MQTT\MQTTUnsubscribe.h ..\Internet\MQTT\MQTTFormat.h \
  ..\Internet\MQTT\StackTrace.h D:\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\ARM\ARMCLANG\Bin\..\include\string.h
