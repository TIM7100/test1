#include "cloud_platform_para.h"


/***********************************************************************************************
 *                                      ��������������                                           *
************************************************************************************************/
const char SubTopicBuff[SUB_TOPIC_COUNT][64] = { "$ota/update/%s/%s", 
									           "$thing/down/property/%s/%s",
//                                               "$shadow/operation/result/%s/%s"
									         };

											
											
void ServerParameterInit(SERVER_INFOR *ServerInfor)
{
	memcpy(ServerInfor->DomainName, SERVER_NAME, sizeof(SERVER_NAME));
	memset(ServerInfor->ServerIP, 0, sizeof(ServerInfor->ServerIP));
	ServerInfor->ServerPort = SERVERPORT;
}

void CloudParameterInit(CLOUD_INFOR *CloudInfor)
{
	strncpy(CloudInfor->ProductKey, PRODUCT_ID, sizeof(PRODUCT_ID));
	strncpy(CloudInfor->DeviceName, DEVICE_NAME, sizeof(DEVICE_NAME));
	strncpy(CloudInfor->DeviceSecret, DEVICE_SECRET, sizeof(DEVICE_SECRET));
}

void MqttParameterInit(MQTT_INFOR *MqttInfor)
{
	memset(MqttInfor->ClientID, 0, sizeof(MqttInfor->ClientID));
	memset(MqttInfor->Username, 0, sizeof(MqttInfor->Username));
	memset(MqttInfor->Passward, 0, sizeof(MqttInfor->Passward));
}

void MqttPackerParameterInit(MQTT_PACKET_INFOR *MqttPacket)
{
	u8 i = 0;
	char SubTopic[64] = {0};
	
	memcpy(MqttPacket->PubTopic, OTA_PUB_TOPIC, sizeof(OTA_PUB_TOPIC));
/* �����µĶ����������Ҫ����������һ�г�ʼ�� */
	for (i = 0; i < SUB_TOPIC_COUNT; i++)
	{
		memset(SubTopic, 0, sizeof(SubTopic));
		sprintf(SubTopic, SubTopicBuff[i], PRODUCT_ID, DEVICE_NAME);
		memcpy(MqttPacket->SubTopic[i], SubTopic, sizeof(SubTopic));
	}
	MqttPacket->Qos = 0;
	MqttPacket->KeepAlive = KEEP_ALIVE;
	MqttPacket->CleanSession = CLEAN_SESSION;
/* �������ݻ����� */
	memset(MqttPacket->DataPacket, 0, DATA_PACKET_LEN);
	MqttPacket->DataPacketLen = DATA_PACKET_LEN;
/* ��Ч�غ����ݻ����� */	
	memset(MqttPacket->UploadTemplate, 0, UPLOAD_TEMPLATE_LEN);	
//	MqttPacket->UploadTemplateLen = 0;	
}

void MqttPubTopicInit(MQTT_PACKET_INFOR *MqttPacket, const char *PubTopic)
{
	char PubTopicBuf[64] = {0};
	if (PubTopic != NULL)
	{
		sprintf(PubTopicBuf, PubTopic, PRODUCT_ID, DEVICE_NAME);
		memset(MqttPacket->PubTopic, 0, 64);
		memcpy(MqttPacket->PubTopic, PubTopicBuf, strlen(PubTopicBuf));
	}
}




