#include "menu_app.h"
#include "bsp_timer7.h"
#include "bsp_usart1.h"
#include "bsp_usart3.h"
#include "w5500_user_conf.h"
#include "esp8266_config.h"

int main(void)
{
    __set_PRIMASK(0);                           //����ȫ���ж�
    System_Init();
    System_Module_Enable(EN_GPIOAB);
    System_Module_Enable(EN_GPIOCD);

	System_Delay_MS(1000);
    UART1_Init(115200);
	UART3_Init(921600);
    MenuBspInit();
    W5500Config();
	WiFi_IO_Init();
	
    while (1)
    {
        MenuOperatingSystem();
    }
}

