#include "menu.h"

const u8 EmptyHex[2] = {0x00, 0x00}; /* �յ�Hex */

MenuItem NullMenuItem;       /* �յ�Menu */
MenuItem NullPMenuItem;


#define FUNC_MENU_NODE        4                 //���ܲ˵��ڵ���
#define LANGUAGE_MENU_NODE    2                 //���Բ˵��ڵ���
/* ��һ��Menu *******************************************************************************************************************/
MenuItem FunctionMenu[] =
{
    /*MenuCount         DisplayString                       ChildrenMenus      ParentMenus        EventCode */
    {FUNC_MENU_NODE,   {"SeriesMenu",      "ϵ�в˵�"},     &NullMenuItem,     &NullMenuItem,     JUMP_EVENT},
    {FUNC_MENU_NODE,   {"UpdateFirmware",  "���¹̼�"},     &NullMenuItem,     &NullMenuItem,     OTA_EVENT},
//   {FUNC_MENU_NODE,   {"InquireCount",    "������������"},     &NullMenuItem,     &NullMenuItem,     COUNT_EVENT},
    {FUNC_MENU_NODE,   {"Language",        "����ѡ��"},     LanguageMenu,      &NullMenuItem,     0xFF},
    {FUNC_MENU_NODE,   {"FactoryReset",    "�ָ���������"}, &NullMenuItem,     &NullMenuItem,     FACTORY_RESET_EVENT},
};



/* �ڶ���Menu ********************************************************************************************************************/
MenuItem LanguageMenu[] =
{
    /*MenuCount             DisplayString                   ChildrenMenus      ParentMenus        EventCode */
    {LANGUAGE_MENU_NODE,    {"English", "English"},         &NullMenuItem,     FunctionMenu,      LANGUAGE_EVENT },
    {LANGUAGE_MENU_NODE,    {"����",    "����"},            &NullMenuItem,     FunctionMenu,      LANGUAGE_EVENT },
};



void NullSubs(void)  /* �պ��� */
{

}



