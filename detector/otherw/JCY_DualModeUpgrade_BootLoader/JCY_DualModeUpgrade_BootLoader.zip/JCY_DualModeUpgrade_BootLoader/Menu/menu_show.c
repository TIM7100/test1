#include "menu_show.h"
#include "menu_app.h"
#include "bsp_uart_lcd.h"
#include "bsp_sdcard.h"
#include "cloud_platform_para.h"
#include "handle_firmware.h"
#include "shadow.h"
#include "bsp_key.h"

u8 UserLastChoose;

static void ClearShow(void)    //���ȫ����ʾЧ��
{
    LCD_UartSend("CLR(0);\r\n");    //����
    LCD_UartSend("DIR(1);\r\n");
}

void DeviceInitShow(void)
{
    ClearShow();
    LCD_UartSend("DC16(24,50,'�豸��ʼ����...',2);\r\n");
    LCD_UartSend("DC16(32,70,'device init...',2);\r\n");
}


void CheckSDCardShow(void)
{
    while (SD_Initialize() != SD_RESPONSE_NO_ERROR)
    {
        ClearShow();
        LCD_UartSend("DC16(20,50,'����SD��',1);\r\n");
        LCD_UartSend("DC16(0,70,'Please Check SD Card',1);\r\n");

        System_Delay_MS(2000);
    }
}

void ProgressBarShow(u32 AllCut, u32 CurrentCut)
{
    char BoxBuf[32] = {0};

    sprintf(BoxBuf, "BOXF(10,75,%02d,90,5);\r\n", ((140 * CurrentCut) / AllCut) + 10);
    LCD_UartSend(BoxBuf);
}

/************* ��ҳ�� *************/
void MainPageShow(u8 ShowLanguage, char* Version)          //��ҳ����ʾ
{
    ClearShow();

    if (ShowLanguage == Chinese)
    {
        LCD_UartSend("DC24(56,10,'��ҳ',2);\r\n");

        LCD_UartSend("DC16(7,46,'�豸����',4);\r\n");
        LCD_UartSend(CMD_DC16(76, 46, DEVICE_NAME, 4));        //��ʾ�豸��

        LCD_UartSend("DC16(7,66,'�豸�汾��',4);\r\n");
        LCD_UartSend(CMD_DC16(88, 66, DEVICE_VERSION, 4));     //��ʾ�汾��

        LCD_UartSend("DC16(7,86,'�̼���',4);\r\n");
        LCD_UartSend(CMD_DC16(60, 86, Version, 4));            //��ʾ�汾��

        LCD_UartSend("DC16(12,110,'- \"Enter\"���� -',4);\r\n");
    }
    else if (ShowLanguage == English)
    {
        LCD_UartSend("DC24(26,10,'Home Page',2);\r\n");

        //��ʾ�豸��
        LCD_UartSend("DC16(7,38,'Device:',4);\r\n");
        LCD_UartSend(CMD_DC16(68, 38, DEVICE_NAME, 4));

        //��ʾ�豸�汾
        LCD_UartSend("DC16(7,54,'DeviceVer:',4);\r\n");
        LCD_UartSend(CMD_DC16(96, 54, DEVICE_VERSION, 4));

        //��ʾ�̼��汾
        LCD_UartSend("DC16(7,70,'Firmware:',4);\r\n");
        LCD_UartSend(CMD_DC16(50, 86, Version, 4));

        LCD_UartSend("DC16(10,110,'- \"Enter\"Next -',4);\r\n");
    }
}

/*******************************************************************************
* Function Name  : MenuShow
* Description    : Ŀ¼��ʾ����
* Input          : None
* Output         : None
* Return         : None
* Remark         :
    ͨ���޸� MenuPoint ��ָ��
    DisplayStart ���޸�menu�ڵ�Ŀ�ʼλ��
    NodeNum      �޸���ʾ�Ĳ˵��ڵ�
*******************************************************************************/
void MenuShow(u8 ShowLanguage)
{
    u8 color;
    u8 n;
    u8 LastNode;
    u8 NowNode;
    u8 ShowNodePoint;
    u8 UserChoosePoint = SelectPoint;
    char Num[4] = {"00."};

    n = 0;
    MaxNodes = MenuPoint[NodeNum].MenuCount; //��һ��Ŀ¼ָ����MainMenu

    if (RefreshFlag != 0)
    {
        ClearShow();
        RefreshFlag = 0;
        if (ShowLanguage == Chinese)
        {
            LCD_UartSend("DC16(35,0,'��ִ�в���',15);\r\n");
        }
        else if (ShowLanguage == English)
        {
            LCD_UartSend("DC16(51,0,'FUNCTION',15);\r\n");
        }

        /* ��ʾ��ǰҳ��Ŀ�ѡ�� */
        for (ShowNodePoint = DisplayStart; ShowNodePoint < DisplayEnd; ShowNodePoint++)
        {
            if ((n + 1) == UserChoosePoint)  // �����ѡ���У�����ʾ��ͬ����ɫ
            {
                color = 6;
            }
            else
            {
                color = 4;
            }
            sprintf(Num, "%02d.", ShowNodePoint + 1);
            LCD_UartSend(CMD_DC16(10, 25 + (n * 20), Num, color));
            LCD_UartSend(CMD_DC16(10 + 24, 25 + (n * 20), MenuPoint[ShowNodePoint].DisplayString[ShowLanguage], color));
            n++;
        }
    }
    else if (NodeChangFlag)                  //�������л�ʱ��ɫ�仯
    {
        NodeChangFlag = 0;
        LastNode = UserLastChoose - 1;
        NowNode = UserChoosePoint - 1;
        if (NowNode != LastNode)
        {
            sprintf(Num, "%02d.", DisplayStart + LastNode + 1);
            LCD_UartSend(CMD_DC16(10, 25 + (LastNode * 20), Num, 4));
            LCD_UartSend(CMD_DC16(34, 25 + (LastNode * 20), MenuPoint[DisplayStart + LastNode].DisplayString[ShowLanguage], 4));

            sprintf(Num, "%02d.", DisplayStart + NowNode + 1);
            LCD_UartSend(CMD_DC16(10, 25 + (NowNode * 20), Num, 6));
            LCD_UartSend(CMD_DC16(34, 25 + (NowNode * 20),  MenuPoint[DisplayStart + NowNode].DisplayString[ShowLanguage], 6));
        }
    }
    UserLastChoose = UserChoosePoint;
}

void JumpResultShow(u8 ShowLanguage, u8 JumpResultCode)
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        if (JumpResultCode == JUMP_FIRMWARE_EMPTY)
        {
            LCD_UartSend("DC16(34,30,'û�ҵ��̼���',2);\r\n");
            LCD_UartSend("DC16(34,46,'����¹̼���',2);\r\n");
        }
        else if (JumpResultCode == JUMP_FIRMWARE_NEW)
        {
            LCD_UartSend("DC16(34,30,'�����¹̼���',2);\r\n");
            LCD_UartSend("DC16(34,46,'����¹̼���',2);\r\n");
        }
        else if (JumpResultCode == JUMP_READ_SD_FAIL)
        {
            LCD_UartSend("DC16(20,50,'����SD��',1);\r\n");
        }
        //LCD_UartSend("DC16(16,90,'- \"Enter\"���� -',4);\r\n");
        StrMiddleShow("- \"Cancel\"ȡ�� -", 106, 4);
        //LCD_UartSend("DC16(12,110,'- \"Cancel\"ȡ�� -',4);\r\n");
    }
    else if (ShowLanguage == English)
    {
        if (JumpResultCode == JUMP_FIRMWARE_EMPTY)
        {
            LCD_UartSend("DC16(8,30,'Firmware not found',2);\r\n");
            LCD_UartSend("DC16(32,46,'Please update',2);\r\n");
        }
        else if (JumpResultCode == JUMP_FIRMWARE_NEW)
        {
            LCD_UartSend("DC16(34,30,'New firmware exist',2);\r\n");
            LCD_UartSend("DC16(0,46,'Please update the firmware',2);\r\n");
        }
        else if (JumpResultCode == JUMP_READ_SD_FAIL)
        {
            LCD_UartSend("DC16(8,70,'Please Check SD Card',1);\r\n");
        }
        //LCD_UartSend("DC16(16,90,'- \"Enter\"Next -',4);\r\n");
        LCD_UartSend("DC16(8,110,'- \"Cancel\"Return -',4);\r\n");
    }
}

void ChooseFactoryResetShow(u8 ShowLanguage)          //�ָ���������ҳ����ʾ
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        LCD_UartSend("DC16(16,42,'�Ƿ�ָ���������',2);\r\n");
        LCD_UartSend("DC16(16,90,'- \"Enter\"���� -',4);\r\n");
        LCD_UartSend("DC16(12,110,'- \"Cancel\"ȡ�� -',4);\r\n");
    }
    else if (ShowLanguage == English)
    {
        LCD_UartSend("DC16(20,42,'restore factory ?',2);\r\n");
        LCD_UartSend("DC16(16,90,'- \"Enter\"Next -',4);\r\n");
        LCD_UartSend("DC16(8,110,'- \"Cancel\"Return -',4);\r\n");
    }
}

void FactoryResetShow(u8 ShowLanguage)
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        LCD_UartSend("DC16(16,55,'�ָ�����������',5);\r\n");
    }
    else if (ShowLanguage == English)
    {
        LCD_UartSend("DC16(16,55,'Factory Reset...',5);\r\n");
    }
}

void SetResultShow(u8 ShowLanguage, u8 Result)
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        switch (Result)
        {
        case LANGUAGE_SET_SUCC:
        case FACTORY_RESET:
            LCD_UartSend("DC24(38,50,'���óɹ�',2);\r\n");
            break;
        }
        LCD_UartSend("DC16(16,110,'- \"Cancel\"���� -',4);\r\n");
    }
    else if (ShowLanguage == English)
    {
        switch (Result)
        {
        case LANGUAGE_SET_SUCC:
        case FACTORY_RESET:
            LCD_UartSend("DC16(24,56,'Set Successfully',2);\r\n");
            break;
        }
        LCD_UartSend("DC16(8,110,'- \"Cancel\"Return -',4);\r\n");
    }
}


void RunningShow(u8 ShowLanguage, u8 Function)          //���ء�����ҳ����ʾ
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        if (Function == LOAD_RUNNING)
        {
            LCD_UartSend("DC16(50,55,'������...',5);\r\n");
        }
        else if (Function == DOWNLOAD_RUNNING)
        {
            LCD_UartSend("DC16(50,55,'������...',5);\r\n");
        }
        else if (Function == UPDATE_RUNNING)
        {
            LCD_UartSend("DC16(18,55,'���±��ع̼���...',5);\r\n");
        }
    }
    else if (ShowLanguage == English)
    {
        if (Function == LOAD_RUNNING)
        {
            LCD_UartSend("DC16(50,55,'Loading...',5);\r\n");
        }
        else if (Function == DOWNLOAD_RUNNING)
        {
            LCD_UartSend("DC16(28,55,'Downloading...',5);\r\n");
        }
        else if (Function == UPDATE_RUNNING)
        {
            LCD_UartSend("DC16(40,55,'Updating...',5);\r\n");
        }
    }
    LCD_UartSend("BOX(10,75,150,90,16);\r\n");
}

void AnalysisShow(u8 ShowLanguage)
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        LCD_UartSend("DC16(24,28,'�¹̼���������',2);\r\n");
        LCD_UartSend("DC16(8,44,'�Ƿ���±��ع̼���',2);\r\n");
        LCD_UartSend("DC16(16,90,'- \"Enter\"���� -',4);\r\n");
        LCD_UartSend("DC16(12,110,'- \"Cancel\"ȡ�� -',4);\r\n");
    }
    else if (ShowLanguage == English)
    {
        LCD_UartSend("DC16(0,28,'Firmware has been downloaded',2);\r\n");
        LCD_UartSend("DC16(24,28,'Update or not',2);\r\n");
        LCD_UartSend("DC16(16,90,'- \"Enter\"Next -',4);\r\n");
        LCD_UartSend("DC16(8,110,'- \"Cancel\"Return -',4);\r\n");
    }
}

void ConnectShow(u8 ShowLanguage)          //����ҳ����ʾ
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        LCD_UartSend("DC16(40,55,'����������',5);\r\n");
    }
    else if (ShowLanguage == English)
    {
        LCD_UartSend("DC16(32,55,'Connecting...',5);\r\n");
    }
}

void TimeOutShow(u8 ShowLanguage)
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        LCD_UartSend("DC16(8,39,'���������Ƿ�����',1);\r\n");
        LCD_UartSend("DC16(22,55,'���������״̬',1);\r\n");
        LCD_UartSend("DC16(16,110,'- \"Cancel\"���� -',4);\r\n");
    }
    else if (ShowLanguage == English)
    {
        LCD_UartSend("DC16(0,39,'Please check network',1);\r\n");
        LCD_UartSend("DC16(8,55,'and network cable',1);\r\n");
        LCD_UartSend("DC16(8,110,'- \"Cancel\"Return -',4);\r\n");
    }
}

void WaitingFirmwareShow(u8 ShowLanguage)          //�ȴ����չ̼���
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        LCD_UartSend("DC16(22,55,'�ȴ����չ̼���..',5);\r\n");
    }
    else if (ShowLanguage == English)
    {
        LCD_UartSend("DC16(16,55,'Waiting Firmware',5);\r\n");
    }
}

void ChooseDownloadShow(u8 ShowLanguage)
{
    ClearShow();
    if (ShowLanguage == Chinese)
    {
        LCD_UartSend("DC16(8,28,'�¹̼������Ƿ�����',2);\r\n");
        LCD_UartSend("DC16(16,90,'- \"Enter\"���� -',4);\r\n");
        LCD_UartSend("DC16(12,110,'- \"Cancel\"ȡ�� -',4);\r\n");
    }
    else if (ShowLanguage == English)
    {
        LCD_UartSend("DC16(11,40,'Download Firmware',2);\r\n");
        LCD_UartSend("DC16(16,90,'- \"Enter\"Next -',4);\r\n");
        LCD_UartSend("DC16(8,110,'- \"Cancel\"Return -',4);\r\n");
    }
}

void DownloadModeShow(u8 ShowLanguage, u8 Mode)
{
    if (ShowLanguage == Chinese)
    {
        if (Mode == ADD_COMMAND)
        {
            LCD_UartSend("DC16(34,8,'-������ϵ��-',2);\r\n");
        }
        else if (Mode == UPDATA_COMMAND)
        {
            LCD_UartSend("DC16(34,8,'-���ع̼���-',2);\r\n");
        }
    }
    else if (ShowLanguage == English)
    {
        if (Mode == ADD_COMMAND)
        {
            LCD_UartSend("DC16(14,8,'-ADD New Series-',2);\r\n");
        }
        else if (Mode == UPDATA_COMMAND)
        {
            LCD_UartSend("DC16(8,8,'-Download Firmware-',2);\r\n");
        }
    }
}

void OTAResultShow(u8 ShowLanguage, u8 Result)
{
    char ErrCode[15] = {0};
    ClearShow();

    sprintf(ErrCode, "Error Code %d", Result);
    if (ShowLanguage == Chinese)
    {
        switch (Result)
        {
        case OTA_COMMAND_ERR:
        case OTA_LOSE_INFO:    //�̼���ȡʧ��
            LCD_UartSend("DC16(20,40,'��ȡ�̼���ʧ��',1);\r\n");
            LCD_UartSend(CMD_DC16(30, 66, ErrCode, 1));
            break;
        case OTA_ADD_SERIES_ZERO:
            LCD_UartSend("DC16(20,40,'���ӵ�ϵ����Ϊ0',1);\r\n");
            break;
        case OTA_DONT_UPDATA:
            LCD_UartSend("DC16(20,50,'��ǰΪ���°汾',2);\r\n");
            break;
        case OTA_SUCCESS:
            LCD_UartSend("DC24(26,40,'���³ɹ�',2);\r\n");
            break;
        default:
            LCD_UartSend("DC24(34,40,'����ʧ��',1);\r\n");
            LCD_UartSend(CMD_DC16(30, 66, ErrCode, 1));
            break;
        }
        LCD_UartSend("DC16(16,110,'- \"Cancel\"���� -',4);\r\n");
    }
    else if (ShowLanguage == English)
    {
        switch (Result)
        {
        case OTA_COMMAND_ERR:
        case OTA_LOSE_INFO:    //�̼���ȡʧ��
            LCD_UartSend("DC16(18,50,'Get Firmware Err',1);\r\n");
            LCD_UartSend(CMD_DC16(30, 68, ErrCode, 1));
            break;
        case OTA_ADD_SERIES_ZERO:
            LCD_UartSend("DC16(18,50,'Added series is 0',1);\r\n");
            break;
        case OTA_DONT_UPDATA:
            LCD_UartSend("DC16(24,55,'Newest Firmware',2);\r\n");
            break;
        case OTA_SUCCESS:
            LCD_UartSend("DC16(10,48,'Updata Successfully',2);\r\n");
            break;
        default:
            LCD_UartSend("DC16(26,48,'Fail to download',1);\r\n");
            LCD_UartSend(CMD_DC16(30, 68, ErrCode, 1));
            break;
        }
        LCD_UartSend("DC16(8,110,'- \"Cancel\"Return -',4);\r\n");
    }
}

//void ShadowCountShow(u8 ShowLanguage, u8 Result, u32 HP95_90Count, u32 HP97Count)
//{
//    char HP97CountBuff[6];
//    char HP95_90CountBuff[6];
//
//    ClearShow();
//  sprintf(HP97CountBuff, "%d", HP97Count);
//    sprintf(HP95_90CountBuff, "%d", HP95_90Count);
//  if (ShowLanguage == Chinese)
//  {
//      switch (Result)
//      {
//        case SHADOW_VERSION_ALIKE:
//            LCD_UartSend("DC16(80,80,'����',15);\r\n");
//            break;
//      case SHADOW_SUCCESS:
//            LCD_UartSend("DC16(80,80,'���³ɹ�',2);\r\n");
//            break;
//        case SHADOW_VERSION_ERR:                //���¼�����ȡʧ��
//      case SHADOW_GET_FAIL:
//            LCD_UartSend("DC16(80,80,'����ʧ��',1);\r\n");
//          break;
//      }
//        LCD_UartSend("DC16(24,4,'-ʣ����������-',15);\r\n");
//
//        LCD_UartSend("DC16(8,32,'HP95_90:',15);\r\n");
//        LCD_UartSend(CMD_DC16(80, 32, HP95_90CountBuff, 2));
//
//        LCD_UartSend("DC16(16,56,'HP97:',15);\r\n");
//        LCD_UartSend(CMD_DC16(80, 56, HP97CountBuff, 2));
//
//        LCD_UartSend("DC16(8,80,'����״̬:',15);\r\n");
//
//        LCD_UartSend("DC16(16,110,'- \"Cancel\"���� -',4);\r\n");
//  }
//  else if (ShowLanguage == English)
//  {
//        switch (Result)
//      {
//      case SHADOW_VERSION_ALIKE:
//            LCD_UartSend("DC16(90,90,'newest',15);\r\n");
//            break;
//      case SHADOW_SUCCESS:
//            LCD_UartSend("DC16(90,90,'update successfully',2);\r\n");
//            break;
//        case SHADOW_VERSION_ERR:                //���¼�����ȡʧ��
//      case SHADOW_GET_FAIL:
//            LCD_UartSend("DC16(90,90,'update failed',1);\r\n");
//          break;
//      }
//        LCD_UartSend("DC16(14,4,'-upgrade points-',15);\r\n");
//        LCD_UartSend("DC16(8,32,'HP95_90:',15);\r\n");
//        LCD_UartSend(CMD_DC16(80, 32, HP95_90CountBuff, 2));
//
//        LCD_UartSend("DC16(16,52,'HP97:',15);\r\n");
//        LCD_UartSend(CMD_DC16(80, 52, HP97CountBuff, 2));
//        LCD_UartSend("DC16(8,72,'update status:',15);\r\n");
//        LCD_UartSend("DC16(8,110,'- \"Cancel\"Return -',4);\r\n");
//  }
//}

void Password_SuccessShow(void)
{
    ClearShow();
    LCD_UartSend("DC16(40,30,'������ȷ',2);\r\n");
    LCD_UartSend("DC16(20,70,'��ȷ����������',4);\r\n");
    LCD_UartSend("DC16(10,100,'-����-Enter-ȷ��-',4);\r\n");
}

void StartResume_Show(void)
{
    ClearShow();
    LCD_UartSend("DC16(10,50,'�ָ�����������...',2);\r\n");
    System_Delay_MS(1000);
}

void ConfirmNetworkConnect_ErrorsShow(void)
{
    ClearShow();
    LCD_UartSend("DC16(30,30,'�޷���������',1);\r\n");
    LCD_UartSend("DC16(5,70,'��ȷ�������Ƿ�����',4);\r\n");
    LCD_UartSend("DC16(20,100,'�������ز˵�...',4);\r\n");
    System_Delay_MS(4000);
}

void Password_ErrorShow(void)
{
    ClearShow();
    LCD_UartSend("DC16(40,30,'�������',1);\r\n");
    LCD_UartSend("DC16(25,80,'�������ز˵�...',4);\r\n");
    System_Delay_MS(2000);
}



void PasswordControl_StartScreen(void)
{
    LCD_UartSend("DC16(30,10,'-����������-',2);\r\n");
    LCD_UartSend("DC16(5,110,'����Enter������һλ',2);\r\n");
    LCD_UartSend("BOX(10,50,45,90,5);\r\n");
    LCD_UartSend("BOX(45,50,80,90,5);\r\n");
    LCD_UartSend("BOX(80,50,115,90,5);\r\n");
    LCD_UartSend("BOX(115,50,150,90,5);\r\n");
    LCD_UartSend("DC24(22,57,'0',5);\r\n");
    LCD_UartSend("DC24(57,57,'0',5);\r\n");
    LCD_UartSend("DC24(92,57,'0',5);\r\n");
    LCD_UartSend("DC24(127,57,'0',5);\r\n");
}

u8 Password_Control(u8 *RightPassword)
{
    u8 KeyValue = KEY_NO_DOWN;
    u8 PasswordLength = 4;             //���볤��
    u8 PasswordNum[4] = {0};           //��ǰһλ������
    u8 EnterKeyFlag = 0;               //ȷ�ϰ���ɨ���־
    u8 CancelKeyFlag = 0;              //�˳�����ɨ���־
    char str[2] = {0, '\0'};

    ClearShow();
    PasswordControl_StartScreen();
    LCD_UartSend("SBC(0);\r\n");

    for (u8 i = 0; i < PasswordLength; i++)
    {
        LCD_UartSend("BOX(10,50,45,90,5);\r\n");
        LCD_UartSend("BOX(45,50,80,90,5);\r\n");
        LCD_UartSend("BOX(80,50,115,90,5);\r\n");
        LCD_UartSend("BOX(115,50,150,90,5);\r\n");
        LCD_UartSend(CMD_BOX(10 + i * 35, 50, 45 + i * 35, 90, 4));
        PasswordNum[i] = 0;

        while (1)
        {
            KeyValue = KeyScan();

            switch (KeyValue)
            {
            case KEY_ENTER_VALUE:
                EnterKeyFlag = 1;
                break;

            case KEY_ESC_VALUE:
                CancelKeyFlag = 1;
                break;

            case KEY_UP_VALUE:
                if (PasswordNum[i] < 9)
                {
                    PasswordNum[i]++;
                }
                str[0] = PasswordNum[i] + '0';
                LCD_UartSend(CMD_DC24(22 + i * 35, 57, str, 5));
                break;

            case KEY_DOWN_VALUE:
                if (PasswordNum[i] > 0)
                {
                    PasswordNum[i]--;
                }
                str[0] = PasswordNum[i] + '0';
                LCD_UartSend(CMD_DC24(22 + i * 35, 57, str, 5));
                break;
            }
            if (EnterKeyFlag)
            {
                EnterKeyFlag = 0;
                break;
            }
            if (CancelKeyFlag)
            {
                return KeyExit;
            }
        }
        if (i == 3)
        {
            //to be done �ж������Ƿ���ȷ
            if (PasswordNum[0] == RightPassword[0] && PasswordNum[1] == RightPassword[1] && \
                PasswordNum[2] == RightPassword[2] && PasswordNum[3] == RightPassword[3])
            {
                return PasswordRight;
            }
            else
            {
                return PasswordError;
            }
        }
    }
    return KeyExit;
}

void WIFI_ConnectShow(void)
{
	ClearShow();
    LCD_UartSend("DC16(0,40,'���������ѱ����WIFI',2);\r\n");
    LCD_UartSend("DC16(32,70,'WIFI Connect...',2);\r\n");
}

void WIFI_ConnectSuccesShow(void)
{
	ClearShow();
    LCD_UartSend("DC16(30,40,'����WIFI�ɹ�',2);\r\n");
	LCD_UartSend("DC16(32,80,����ִ����...',2);\r\n");
}


void SmartConfig_RequestShow(void)
{
    ClearShow();
	LCD_UartSend("DC16(33,20,'�޷������ѱ����WIFI��',4);\r\n");
    LCD_UartSend("DC16(70,40,'��ʹ��С�����������...',4);\r\n");
	LCD_UartSend("DC16(40,80,'��ʱ3����',4);\r\n");
}

void SmartConfig_SuccessShow(void)
{
    ClearShow();
    LCD_UartSend("DC16(50,30,'�����ɹ�',2);\r\n");
	LCD_UartSend("DC16(30,50,'��������WIFI',2);\r\n");
	LCD_UartSend("DC16(32,90,����ִ����...',2);\r\n");
}

void SmartConfig_ErrorShow(void)
{
    ClearShow();
	LCD_UartSend("DC16(50,40,'����ʧ��',1);\r\n");
    LCD_UartSend("DC16(35,80,'�˳�/������...',4);\r\n");
}